<html>
<head><title>XDebug: Test-Ausgabe</title></head>
<body>
<p>If xdebug is properly installed then script started in step 1. should print message like "connection established: Resource id #5".<br> 
If no message is printed and the script is still running, then xdebug isn't installed properly or uses different port or whatever else.<br> 
So, kill the running process and investigate where the problem is, but this is the other story.</p>
<hr>
<?php
$address = '127.0.0.1';
$port = 9000;
$sock = socket_create(AF_INET, SOCK_STREAM, 0);
socket_bind($sock, $address, $port) or die('Unable to bind');
socket_listen($sock);
$client = socket_accept($sock);
echo "connection established: $client";
socket_close($client);
socket_close($sock);
?>
</body>
</html>
