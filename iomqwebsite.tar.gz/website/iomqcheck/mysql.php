<html>
<head><title>MySQL-Check</title></head>
<body>
<?php
$mysql = new mysqli("localhost", "root");
echo "MySQL Server info: ".$mysql->host_info;
?>
</body>
</html>
