<html>
<head><title>Zeit-Check</title></head>
<body>
<?php
setlocale(LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');   putenv( "PHP_TZ=Europe/Berlin" );


$timestamp = time();
$datum = date("d.m.Y - H:i:s", $timestamp);
echo "Datum - Zeit:&nbsp;".$datum;


echo "<br>";
$WTAG = date('l');
echo "Wochentag:&nbsp;&nbsp;&nbsp;".$WTAG;


echo "<br>";
//echo system("locale");  
echo "<br>";

/* try different possible locale names for german as of PHP 4.3.0 */
$loc_de = setlocale(LC_ALL, 'de_DE@euro', 'de_DE', 'de', 'ge');
echo "Preferred locale for german on this system is '$loc_de'";

?>
</body>
</html>
