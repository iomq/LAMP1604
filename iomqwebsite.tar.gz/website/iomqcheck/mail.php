<html>
<head><title>EMail-Check</title></head>
<body>
<?php
echo "EMail ";
mail("test@test","Test","Hallo,\ndas ist ein Test!\n\nMfg\nIOMQ-Tools","From: test@test");
echo "schicken.";
?>
</body>
</html>
