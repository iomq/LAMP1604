<html>
<head><title>XDebug: Info</title></head>
<body>
<p>You can check your configuration using simple script written by Radek Matous and posted on blog.oracle.com.<br>
If you are using WAMP then you don't have php on path, most probably.<br>
All you have to do is to copy this code to php file and then call it from browser with $_GET variable in url ?XDEBUG_SESSION_START=mysession.<br>
Let's say your file i called dbgtest.php and it's in web directory.</p>
<p>All you have to do is type http://localhost/iomqcheck/dbgtest.php?XDEBUG_SESSION_START=mysession.</p>
<p>If xdebug is properly installed then script started in step 1. should print message like "connection established: Resource id #5".<br> 
If no message is printed and the script is still running, then xdebug isn't installed properly or uses different port or whatever else.<br> 
So, kill the running process and investigate where the problem is, but this is the other story.</p>
<hr>
<a href="dbgtest.php?XDEBUG_SESSION_START=mysession">XDebug-Test</a>
</body>
</html>
