<html>
<head><title>Hallo PHP</title></head>
<body>
<?php
echo "<h1>Hallo PHP!</h1>";
echo "Test";
?>
</body>
</html>
