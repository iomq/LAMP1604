<html>
<head><title>PHP-Info</title></head>
<body>
<?php
phpinfo();
?>
</body>
</html>
